import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { ApplicationsComponent } from './applications/applications.component';
import { SignupComponent } from './signup/signup.component';
import { IframeComponent } from './iframe/iframe.component';
import { HeaderComponent } from './header/header.component';
import { DemoComponent } from './demo/demo.component';
import { Demo1Component } from './demo1/demo1.component';
import { SubmitComponent } from './submit/submit.component';
import { ApplicationOneComponent } from './application-one/application-one.component';
import { Demo2Component } from './demo2/demo2.component';
import { GraphComponent } from './graph/graph.component';
import { WorkflowComponent } from './workflow/workflow.component';





const routes: Routes = [
  { path : '', component : LoginComponent },
  { path : 'welcome', component : WelcomeComponent},
  { path : 'applications', component : ApplicationsComponent},
  { path : 'signup', component : SignupComponent},
  { path : 'iframe', component : IframeComponent},
  { path : 'header', component : HeaderComponent},
  { path : 'demo', component : DemoComponent},
  { path : 'demo1', component : Demo1Component},
  { path : 'submit', component : SubmitComponent},
  { path : 'applicationOne', component : ApplicationOneComponent},
  { path : 'demo2', component : Demo2Component},
  { path : 'graph', component : GraphComponent},
  { path : 'workflow', component : WorkflowComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
