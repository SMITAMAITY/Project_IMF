import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovegraphComponent } from './approvegraph.component';

describe('ApprovegraphComponent', () => {
  let component: ApprovegraphComponent;
  let fixture: ComponentFixture<ApprovegraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApprovegraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApprovegraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
