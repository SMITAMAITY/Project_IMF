import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IngestionFourComponent } from './ingestion-four.component';

describe('IngestionFourComponent', () => {
  let component: IngestionFourComponent;
  let fixture: ComponentFixture<IngestionFourComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IngestionFourComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IngestionFourComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
