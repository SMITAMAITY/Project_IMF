import { Component, OnInit } from '@angular/core';
import { UserDetails, AuthenticationService } from '../authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent {
  details:UserDetails
  constructor(public auth: AuthenticationService,private router : Router){}

  ngOnInit() {

    

    this.auth.profile().subscribe(
      user => {
          this.details =user
      },
      err => {
          console.error(err)
      }

  )
    }


    back(): void {

    this.auth.profile().subscribe(
      user => {
          this.details =user
          if(user.role == 'Approver'){
          
              this.router.navigate(['/applicationOne']);
            
          }


          if(user.role == 'User')
          {
              
              this.router.navigate(['/applications']);
        
            }
      
            },
                err => {
                    console.error(err)
                 })
          }
        }
      


