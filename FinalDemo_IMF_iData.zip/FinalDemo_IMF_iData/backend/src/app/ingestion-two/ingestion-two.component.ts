import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ingestion-two',
  templateUrl: './ingestion-two.component.html',
  styleUrls: ['./ingestion-two.component.css']
})
export class IngestionTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
