import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ingestion-six',
  templateUrl: './ingestion-six.component.html',
  styleUrls: ['./ingestion-six.component.css']
})
export class IngestionSixComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }


  approve(){
    this.router.navigateByUrl('approvegraph')
  }

  reject(){
    this.router.navigateByUrl('rejectgraph')
  }
}
