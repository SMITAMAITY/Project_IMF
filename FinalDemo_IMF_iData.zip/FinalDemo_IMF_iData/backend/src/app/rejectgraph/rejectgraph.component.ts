import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { AuthenticationService, UserDetails } from '../authentication.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-rejectgraph',
  templateUrl: './rejectgraph.component.html',
  styleUrls: ['./rejectgraph.component.css']
})
export class RejectgraphComponent implements OnInit {

  form = new FormGroup({
    reason:new FormControl('', [Validators.required])
  })
// text={reason:''}

  details:UserDetails;
  taskData: any[] = [];

  public apidata;
  httpOption = {
    headers: new HttpHeaders({
      'Authorization': 'Basic ' + btoa('imf.demo:Appian123'),
      'Content-Type': 'application/json'
    })
  }

  constructor(private httpClient: HttpClient, private router: Router,public auth: AuthenticationService ) { }


  apiurl1 = ` https://lntdemo.appiancloud.com/suite/webapi/dissemination`;

  ngOnInit(): void {
  }

  onRejectData(){
   

      console.log(this.httpOption);
      let taskIds = JSON.parse(localStorage.getItem('taskId'));
      this.httpClient.post(this.apiurl1, {"country":"India","economist":"Dadan.Sikandar","rejectionMessage": this.form.value}, this.httpOption).subscribe(
        data => {
          console.log(data);
          console.log(this.form.value);
          // this.httpClient.get(this.apiurl1 + '' + data['ProcId'], this.httpOption).subscribe(response => {
          //   this.apidata = response;
          //   console.log(this.apidata);
          //   this.taskData.push(this.apidata);
          //   console.log(this.taskData);
          //   localStorage.setItem('dummyData', this.taskData.toString());
          //   // alert('Reject')
           this.router.navigateByUrl('applications')
         //  localStorage.removeItem('dummyData');
          });
        
  }

}
