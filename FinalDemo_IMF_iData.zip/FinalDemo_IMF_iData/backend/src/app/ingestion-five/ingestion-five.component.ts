import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ingestion-five',
  templateUrl: './ingestion-five.component.html',
  styleUrls: ['./ingestion-five.component.css']
})
export class IngestionFiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
