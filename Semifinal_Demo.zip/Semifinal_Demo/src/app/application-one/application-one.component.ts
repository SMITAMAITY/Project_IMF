import { Component, OnInit, Output, Input } from '@angular/core';
import { AuthenticationService, UserDetails } from '../authentication.service'
import { Router } from '@angular/router';
import { Demo2Component } from '../demo2/demo2.component';
import { SubmitService } from '../submit.service';


import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';

import { Subject } from 'rxjs';


@Component({
  selector: 'app-application-one',
  templateUrl: './application-one.component.html',
  styleUrls: ['./application-one.component.css']
})
export class ApplicationOneComponent implements OnInit {
  details: UserDetails;
  message: string;

  public show: boolean = false;
  public buttonName: any = 'Show Notification';



  taskIds:any;

  taskData: any[] = [];

  public apidata;
  httpOption = {
    headers: new HttpHeaders({
      'Authorization': 'Basic ' + btoa('imf.demo:Appian123'),
      'Content-Type': 'application/json'
    })
  }

 

  apiurl = `https://lntdemo.appiancloud.com/suite/webapi/TaskId?procId=`;

  constructor(private submitService: SubmitService, public auth: AuthenticationService, private router: Router, private httpClient: HttpClient) { }


  ngOnInit(): void {
  
    console.log(localStorage.getItem('dummyData').toString());
    console.log(this.submitService.getTaskData());

    if (localStorage.getItem("usertoken") == null) {
      alert('Please login First')
      this.router.navigateByUrl('')
    }
    this.auth.profile().subscribe(
      user => {
        this.details = user;

      },
      err => {
        console.error(err)
      }
    )
  }






  
onSubmit():void{
  this.show = !this.show;
  console.log(this.httpOption);
this.taskIds = JSON.stringify(localStorage.getItem('dummyData'));

  console.log( JSON.parse(localStorage.getItem('dummyData')));
  console.log(this.taskIds)
  // this.httpClient.post(this.apiurl, JSON.stringify({"taskId":taskIds[taskIds.length-1]['taskId'],"action":"Approve"}), this.httpOption).subscribe(
  //   data => {
  // this.httpClient.get(this.apiurl + '' + data['ProcId'], this.httpOption).subscribe(response => {
  //   this.apidata = response;
  //   console.log(this.apidata);
  //   this.taskData.push(this.apidata);
  //   console.log(this.taskData);
  //   localStorage.setItem('dummyData', JSON.stringify(this.taskData));
    // alert('Reject')
   //this.router.navigateByUrl('applications')
 // });

}
}
