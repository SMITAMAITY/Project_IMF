import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-submit',
  templateUrl: './submit.component.html',
  styleUrls: ['./submit.component.css']
})
export class SubmitComponent implements OnInit {

  httpOption = {
    headers: new HttpHeaders({
      'Authorization': 'Basic ' + btoa('imf.demo:Appian123'),
      'Content-Type': 'application/json'
    })
  }

  /* httpOption = {
    headers: new HttpHeaders().set('Content-Type', 'application/json').append('Authorization', 'Basic ' + btoa('imf.demo:Appian123'))
  } */

  apiurl=`https://lntdemo.appiancloud.com/suite/webapi/IMFiData`;
  constructor( private httpClient : HttpClient ) { }

  ngOnInit() {
 
  }

  onSubmit():void{
    console.log(this.httpOption);
    this.httpClient.post(this.apiurl, JSON.stringify({"approver":"imf.demo"}), this.httpOption).subscribe(data=>{

    })
  }
 

}
