import { Component, OnInit, Output, Input } from '@angular/core';
import { AuthenticationService, UserDetails } from '../authentication.service'
import { Router } from '@angular/router';
import { Demo2Component } from '../demo2/demo2.component';
import { SubmitService } from '../submit.service';


@Component({
  selector: 'app-application-one',
  templateUrl: './application-one.component.html',
  styleUrls: ['./application-one.component.css']
})
export class ApplicationOneComponent implements OnInit {
  details: UserDetails;
  message: string;

  public show: boolean = false;
  public buttonName: any = 'Show Notification';


  constructor(private submitService: SubmitService, public auth: AuthenticationService, private router: Router) { }


  ngOnInit(): void {
  
    console.log(localStorage.getItem('dummyData').toString());
    console.log(this.submitService.getTaskData());

    if (localStorage.getItem("usertoken") == null) {
      alert('Please login First')
      this.router.navigateByUrl('')
    }
    this.auth.profile().subscribe(
      user => {
        this.details = user;

      },
      err => {
        console.error(err)
      }
    )
  }
  toggle() {
    this.show = !this.show;

    // CHANGE THE NAME OF THE BUTTON.
    if (this.show) {
      this.buttonName = "Hide Notification";
      //console.log(this.submitService.getTaskData());
      
    }
    else {
      this.buttonName = "Show Notification";
      
    }
  }
}
