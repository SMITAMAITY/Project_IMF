import { Component, OnInit, Output, Input } from '@angular/core';
import { AuthenticationService, UserDetails } from '../authentication.service'
import { Router } from '@angular/router';
import { Demo2Component } from '../demo2/demo2.component';
import { SubmitService } from '../submit.service';


import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';

import { Subject } from 'rxjs';


@Component({
  selector: 'app-application-one',
  templateUrl: './application-one.component.html',
  styleUrls: ['./application-one.component.css']
})
export class ApplicationOneComponent implements OnInit {
  details: UserDetails;
  message: string;

  public show: boolean = false;
  public buttonName: any = 'Show Notification';

 data:any;
 data2 : any;
 data3 : any;

  taskIds:any;

  taskData: any[] = [];

  public apidata:any;
  httpOption = {
    headers: new HttpHeaders({
      'Authorization': 'Basic ' + btoa('imf.demo:Appian123'),
      'Content-Type': 'application/json'
    })
  }

 

  //apiurl = `https://lntdemo.appiancloud.com/suite/webapi/TaskId?procId=`;
  apiurl = `https://lntdemo.appiancloud.com/suite/webapi/BondYeildAPI?username=Dadan.Sikandar`;

  constructor(private submitService: SubmitService, public auth: AuthenticationService, private router: Router, private httpClient: HttpClient) { }


  ngOnInit(): void {
  
    //console.log(sessionStorage.getItem('dummyData').toString();
    //console.log(this.submitService.getTaskData());

    if (localStorage.getItem("usertoken") == null) {
      alert('Please login First')
      this.router.navigateByUrl('')
    }
    this.auth.profile().subscribe(
      user => {
        this.details = user;

      },
      err => {
        console.error(err)
      }
    )
  }

check():void{
  if(sessionStorage.getItem('dummyData')==null)
  {
    this.router.navigateByUrl('applicationOne')
  }
  else{
    this.router.navigateByUrl('demo2');
  }
 
}



  
onClick():void{
  this.show = !this.show;
//   console.log(this.httpOption);
// this.taskIds = JSON.stringify(sessionStorage.getItem('dummyData'));

//   console.log( JSON.parse(sessionStorage.getItem('dummyData')));
//   console.log(this.taskIds)
 


  this.httpClient.get(this.apiurl ,this.httpOption).subscribe(response => {
   


   // this.apidata = response;
   this.apidata = response;
   this.data  = this.apidata.Result1;
   console.log(this.data)

   this.data2  = this.apidata.Result2;
   console.log(this.data2)

    this.data3  = this.apidata.Result3;
    console.log(this.data3)


    
    this.taskData.push(this.apidata);
    console.log(this.taskData);
 


 });

}
}
