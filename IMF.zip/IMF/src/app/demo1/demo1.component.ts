import { Component, OnInit } from '@angular/core';
import { AuthenticationService, UserDetails } from '../authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-demo1',
  templateUrl: './demo1.component.html',
  styleUrls: ['./demo1.component.css']
})
export class Demo1Component implements OnInit {


  details:UserDetails

   
  constructor(public auth: AuthenticationService,private router : Router){}

  ngOnInit() {

    
      if(localStorage.getItem("usertoken") == null){
        alert('Please login First')
     
    }
 
    
      this.auth.profile().subscribe(
          user => {
              this.details =user
          }

      )

 
        }
}
