import { Component, OnInit } from '@angular/core';
import { AuthenticationService, UserDetails } from '../authentication.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-ingestion-two',
  templateUrl: './ingestion-two.component.html',
  styleUrls: ['./ingestion-two.component.css']
})
export class IngestionTwoComponent implements OnInit {

  details:UserDetails

  constructor(public auth: AuthenticationService,private router : Router) { }

  ngOnInit(): void {
    this.auth.profile().subscribe(
      user => {
          this.details =user
      })
    
  }

  

}



