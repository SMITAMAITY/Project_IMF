import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { AuthenticationService, UserDetails } from '../authentication.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-rejectgraph',
  templateUrl: './rejectgraph.component.html',
  styleUrls: ['./rejectgraph.component.css']
})
export class RejectgraphComponent implements OnInit {
  details:UserDetails;
  form = new FormGroup({
    reason:new FormControl('', [Validators.required])
  })
// text={reason:''}


  taskData: any[] = [];

  public apidata;
  httpOption = {
    headers: new HttpHeaders({
      'Authorization': 'Basic ' + btoa('imf.demo:Appian123'),
      'Content-Type': 'application/json'
    })
  }

  constructor(private httpClient: HttpClient, private router: Router,public auth: AuthenticationService ) { }


  apiurl1 = ` https://lntdemo.appiancloud.com/suite/webapi/dissemination`;

  ngOnInit(): void {
  }

  onRejectData(){
    this.auth.profile().subscribe(
      user => {
          this.details =user
          console.log(user.Name)
          let taskIds = JSON.parse(localStorage.getItem('taskId'));
          this.httpClient.post(this.apiurl1, {"country":"India","economist":user.Name, "reason":this.form.value}, this.httpOption).subscribe(
            data => {
              console.log(data);
              console.log(this.form.value);
              
               
             //  localStorage.removeItem('dummyData');
              });
              this.router.navigateByUrl('applications')
      },
      err => {
          console.error(err)
      }
   
  )
   
    //var name = this.details.Name;
    
   //let name = localStorage.getItem('name')
    //console.log(name);
     
        
  }

}
