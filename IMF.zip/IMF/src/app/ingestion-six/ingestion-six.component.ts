import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService, UserDetails } from '../authentication.service';

@Component({
  selector: 'app-ingestion-six',
  templateUrl: './ingestion-six.component.html',
  styleUrls: ['./ingestion-six.component.css']
})
export class IngestionSixComponent implements OnInit {

  details:UserDetails

  constructor(public auth: AuthenticationService,private router : Router) { }

  ngOnInit(): void {

    this.auth.profile().subscribe(
      user => {
          this.details =user
      }
  
  )

}



}
